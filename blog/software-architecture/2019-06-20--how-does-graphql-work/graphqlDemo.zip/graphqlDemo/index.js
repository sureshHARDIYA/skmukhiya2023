const { ApolloServer, gql } = require("apollo-server");
const patient = require("./db");

const typeDefs = gql`
  enum enumNameType {
    official
    usual
    temp
    nickname
    anonymous
    old
    maiden
  }

  enum addressEnumType {
    home
    work
    temp
    old
    billing
  }

  enum addressTypeEnum {
    postal
    physical
    both
  }

  type Patient {
    resourceType: String
    id: ID!
    active: Boolean
    name: [NameSchema]
    gender: String
    address: [AddressSchema]
  }

  type AddressSchema {
    use: addressEnumType
    type: addressTypeEnum
    text: String
    line: String
    city: String
    district: String
    state: String
    postalCode: String
    country: String
  }

  type NameSchema {
    use: enumNameType
    family: String
    given: [String]
  }

  type Query {
    patient: [Patient]
    patientById(id: ID!): Patient
  }
`;

const resolvers = {
  Query: {
    patient: () => patient,
    patientById: (parent, args, context, info) => {
      return patient.filter(item => item.id === args.id)[0];
    }
  }
};

const server = new ApolloServer({ typeDefs, resolvers });

server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url}`);
});
