const patient = [
  {
    "resourceType": "Patient",
    "id": "patients0001",
    "active": true,
    "name": [
    {
      "use": "official",
      "family": "Stark",
      "given": [
        "Arya"
      ]
    },
  ],
  "gender": "female",
  "address": [
    {
      "use": "home",
      "type": "physical",
      "text": "The North, Winterfell",
    }
  ],
},
{
    "resourceType": "Patient",
    "id": "patients0002",
    "active": true,
    "name": [
    {
      "use": "official",
      "family": "Snow",
      "given": [
        "Jon"
      ]
    }
  ],
  "gender": "female",
  "address": [
    {
      "use": "home",
      "type": "physical",
      "text": "The North, Winterfell",
    }
  ],
},
{
    "resourceType": "Patient",
    "id": "patients0003",
    "active": false,
    "name": [
    {
      "use": "official",
      "family": "Targaryen",
      "given": [
        "Daenerys"
      ]
    }
  ],
  "gender": "female",
  "address": [
    {
      "use": "home",
      "type": "physical",
      "text": "The Crownlands",
    }
  ],
},
{
    "resourceType": "Patient",
    "id": "patients0004",
    "active": false,
    "name": [
    {
      "use": "official",
      "family": "Lannister",
      "given": [
        "Cersei"
      ]
    }
  ],
  "gender": "female",
  "address": [
    {
      "use": "home",
      "type": "physical",
      "text": "The Westerlands",
    },
    {
      "use": "home",
      "type": "postal",
      "text": "The Crownlands",
    }
  ],
  }
];

module.exports = patient;
